package assignment3;

import java.util.Random;

public class AccountDetails {

	public int acctNo(int acctnum){
		return acctnum;
	}
	public String acctName(String acctName){
		return acctName;
	}
	public float acctBalance(float acctBalance){
		return acctBalance;
	}
	public void deposit(){
		System.out.println("Deposit Successfully");
		this.creditCard();
	}
	public void withdraw(){
		System.out.println("Withdraw Successfully");
		this.creditCard();
	}
	public long creditCard(){
		Random random= new Random();
		return random.nextLong();
		
	}
}
