package assignments;

import org.springframework.web.bind.annotation.*;

@RestController
public class ConvertLowerCase {

	@PostMapping("lowerCase")
	public String nameLowerCase(@RequestParam("name") String name){
		
		String lowerCaseName=name.toLowerCase();
		 return lowerCaseName;
	}
}
