package assignments;

import javax.ws.rs.core.Response;
import org.springframework.web.bind.annotation.*;

@RestController
public class AlbumController {

	@PostMapping(value="/jsonTojavaConvert" ,consumes = "application/json")
	public Response JSONToJAVAConvert(@RequestBody Album album){
		String result = "Track saved : " + album;
		return Response.status(201).entity(result).build();
		
	}
	
	@PostMapping(value="/javaTojsonConvert" ,produces = "application/json")
      public Album JAVAToJSONConvert(){
		Album album=new Album();
		album.setTitle("ABVD");
		album.setSinger("qwert");
		return album;
	}
	
}
