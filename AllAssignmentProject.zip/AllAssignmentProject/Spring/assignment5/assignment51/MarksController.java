package assignment51;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MarksController {

	
	@RequestMapping("/calculateMarks")
	public String calculateMarks(@ModelAttribute("marks") Marks marks,Model model){
		Double science=marks.getScience_Marks();
		Double english=marks.getEnglish_Marks();
		Double math=marks.getMaths_Marks();
		Double sum=science+math+english;
		model.addAttribute("sum",sum);
		return "result";
	}
	
	@RequestMapping("/")
	public String showForm(Model Model){
		Marks allMarks=new Marks();
		Model.addAttribute("marks",allMarks);
		return "marks";
		
	}
}
