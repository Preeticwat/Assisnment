package assignment42;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;

import assignment3.Student;

public class StudentDAO {

	@Autowired
	HibernateTemplate template;
	public void setTemplate(HibernateTemplate template){
		this.template=template;
	}
	public List<Student> getAllDetails(){
		List<Student> list=new ArrayList<Student>();
		list=template.loadAll(Student.class);
		return list;
	}
	public Student getDetails(String studentId){
		Student student=(Student)template.get(Student.class,studentId);
		return student;
	}
	
}
