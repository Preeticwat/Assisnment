package assignments.assignment1;

import org.springframework.web.bind.annotation.*;

@RestController
public class CreditCardApproval {
	
@PostMapping(value="/validateCard")
public boolean checkValidCreditCard(@RequestParam("creditCard") String creditCard){
	boolean result=false;
     long cardNumber= Long.valueOf(creditCard);
     if(cardNumber%2==0)
     {
    	 result =true; 
     }else{
    	result= false;
     }
     return result;
}
}
