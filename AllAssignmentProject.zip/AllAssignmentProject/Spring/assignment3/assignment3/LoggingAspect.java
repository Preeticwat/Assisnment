package assignment3;

import java.util.Date;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.*;;


@Aspect
@Component
public class LoggingAspect {

	private static long start;
	
	@Before("execution(* assignment3.StudentDAO.*(..))")
	public void logBefore(JoinPoint point) throws Throwable{
		start=System.currentTimeMillis();
	}
	
	@After("execution(* assignment3.StudentDAO.*(..))")
	public void logAfter(JointPoint point) throws Throwable{
		System.out.println(point.getSignature().toShortString()+"Total Execution Time"+
	         (System.currentTimeMillis()-start)+"ms");
	}
	@AfterReturning(point="execution(* assignment3.StudentDAO.getDetails(..))",returning="retVal")
	public void logAfterReturningGetStudent(Object retVal) throws Throwable{
		System.out.println("getDetails() invoked at"+new Date());
	}
	@AfterReturning(point="execution(* assignment3.StudentDAO.getAllDetails(..))")
	public void logAfterReturningAllStudent() throws Throwable{
		System.out.println("getDetails() invoked at"+new Date());
	}
	
}
