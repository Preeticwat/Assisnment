package assignment5;
import javax.persistence.*;

@Entity  
@PrimaryKeyJoinColumn(name="employeeID")  
public class ContractEmployee extends Employee{
       private String allowance;

	public String getAllowance() {
		return allowance;
	}

	public void setAllowance(String allowance) {
		this.allowance = allowance;
	}
       
}
