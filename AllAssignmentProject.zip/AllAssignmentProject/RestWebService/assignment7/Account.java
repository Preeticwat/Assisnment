package assignments;

public class Account {
   private Double amount;
   private String acctnum;
public Double getAmount() {
	return amount;
}
public void setAmount(Double amount) {
	this.amount = amount;
}
public String getAcctnum() {
	return acctnum;
}
public void setAcctnum(String acctnum) {
	this.acctnum = acctnum;
}
   
}
