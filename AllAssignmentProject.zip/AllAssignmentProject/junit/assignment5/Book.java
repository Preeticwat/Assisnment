package assignment5;

public class Book {
	
public double discountedPrice(int price,double discount){
	double totalAmount=price-discount;
	return totalAmount;
}
	
}
