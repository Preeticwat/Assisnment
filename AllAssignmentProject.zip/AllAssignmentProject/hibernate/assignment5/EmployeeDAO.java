package assignment5;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class EmployeeDAO {

	public void saveContractEmployee(ContractEmployee emp) {
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		session.save(emp);
		session.getTransaction().commit();
		session.close();
		System.out.println("Succesfully saved "+ emp.getEmployeeName());
		
	}
	public void saveRegularEmployee(RegularEmployee emp) {
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		session.save(emp);
		session.getTransaction().commit();
		session.close();
		System.out.println("Succesfully saved "+ emp.getEmployeeName());
		
	}
	
	public void deleteEmployee(String employeeId) {
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		Employee emp = session.get(Employee.class, employeeId);
		session.delete(emp);
		session.getTransaction().commit();
		session.close();
		System.out.println("Succesfully deleted");
		
	}

}