package assignment4;

import static org.junit.Assert.*;
import org.junit.*;

public class TestConnection {
	private static String drivername;
	private static String url;
	private static String username;
	private static String pwd;
	
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception{
		drivername="com.microsoft.jdbc.sqlserver.SQLServerDriver";
		url="dbc:microsoft:sqlserver://host:1433";
		username="username";
		pwd="password";
	}
	
	@Test
	public void dbConnectionTest() throws Exception{
		DBConnection dbConnection=new DBConnection();
		String connection=dbConnection.connect(drivername, url, username, pwd);
		assertTrue(connection!=null);
	}

}
