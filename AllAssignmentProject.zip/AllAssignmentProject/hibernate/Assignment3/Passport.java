package Assignment3;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Passport {

	@Id 
	private String passportNum;

	public String getPassportNum() {
		return passportNum;
	}

	public void setPassportNum(String passportNum) {
		this.passportNum = passportNum;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	private String address;

}
