package Assignment3;

public class Client {

	public static void main(String[] args) {
		Employe_ emp=new Employe_();
		emp.setEmployeeId("E12345678");
		emp.setEmployeeName("Employee 2");
		
		Passport psprt=new Passport();
		psprt.setPassportNum("P12345678 ");
		psprt.setAddress("ABC street");
		
		emp.setPasport(psprt);
		
		Employee_DAO empDao=new Employee_DAO();
		empDao.saveEmployee(emp);
		//empDao.deleteEmployee("E1234");
	}
}
