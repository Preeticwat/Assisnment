package assignment1;

public class WordCount {
	int count(String str){
		String arrayStr[]=str.split(" ");
		int count=arrayStr.length;
		return count;
	}

}
