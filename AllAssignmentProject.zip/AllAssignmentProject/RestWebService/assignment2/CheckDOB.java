package assignments;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Calendar;
import java.util.Date;

import org.springframework.web.bind.annotation.*;

@RestController
public class CheckDOB {

	@PostMapping("checkDob")
	public String checkDateOfBirth(@RequestParam("dob") String dob) throws ParseException{
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
		Date birthDate=sdf.parse(dob);
		Calendar calendar=Calendar.getInstance();
		calendar.setTime(birthDate);
		int year=calendar.get(Calendar.YEAR);
		int month=calendar.get(Calendar.MONTH);
		int date=calendar.get(Calendar.DATE);
		LocalDate ldate=LocalDate.of(year, month, date);
		LocalDate now=LocalDate.now();
		Period age=Period.between(ldate, now);
		
		return "age:" +age.getYears()+" years "+ age.getMonths()+" months "+age.getDays()+" days";
		
		
	}
	
}
