package Assignment1;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Employee_DAO {
	
	public void createEmployee(Employee_ emp) {
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		session.save(emp);
		session.getTransaction().commit();
		session.close();
		System.out.println("Succesfully created "+ emp.getEmployeeName());
		
	}
	public void retrieveEmployee(String employeeId) {
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
		Session session=sessionFactory.openSession();
		Employee_ emp = session.get(Employee_.class, employeeId);
		session.close();
		System.out.println("Succesfully retrieve "+ emp.getEmployeeName());
		
	}
	public void updateEmployeeName(String employeeId,String updatedName) {
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		Employee_ emp = session.get(Employee_.class, employeeId);
		String previousName=emp.getEmployeeName();
		emp.setEmployeeName(updatedName);
		session.save(emp);
		session.getTransaction().commit();
		session.close();
		System.out.println("Succesfully updated from "+previousName+" to "+ emp.getEmployeeName());
		
	}
	public void deleteEmployee(String employeeId) {
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		Employee_ emp = session.get(Employee_.class, employeeId);
		session.delete(emp);
		session.getTransaction().commit();
		session.close();
		System.out.println("Succesfully deleted");
		
	}

}
