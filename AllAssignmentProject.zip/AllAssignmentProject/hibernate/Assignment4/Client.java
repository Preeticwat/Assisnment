package Assignment4;

public class Client {
	public static void main(String[] args) {
		
		Students s1= new Students();
		s1.setStudentId("S1");
		s1.setStudentName("A");
		
		Course javaCourse= new Course();
		javaCourse.setcId("J101");
		
		
		
		Course pythonCourse= new Course();
		pythonCourse.setcId("P101");
		
		//one student having multiple courses
		s1.getCourses().add(javaCourse);
		s1.getCourses().add(pythonCourse);
		
		
		
		Students s2= new Students();
		s2.setStudentId("S2");
		s2.setStudentName("B");
		s2.getCourses().add(pythonCourse);
		
		Students s3= new Students();
		s3.setStudentId("S3");
		s3.setStudentName("ABC");
		
		// same course opted by multiple students S2 an s3
		javaCourse.getStudents().add(s3);
		javaCourse.getStudents().add(s2);
		
		Student_Course_DAO student_Course_DAO=new Student_Course_DAO();
		
		/*Student with multiple courses*/
		student_Course_DAO.saveStudent(s1);
		
		
		
		
		
		
	
		
	}

}
