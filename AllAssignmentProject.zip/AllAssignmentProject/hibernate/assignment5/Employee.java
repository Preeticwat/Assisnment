package assignment5;
import javax.persistence.*;
@Entity  
@Inheritance(strategy=InheritanceType.JOINED)  
public class Employee {
	
	@Id  
	@GeneratedValue(strategy=GenerationType.AUTO)  
	private String employeeID;
	private String employeeName;
	private String employeeSalary;
	public String getEmployeeID() {
		return employeeID;
	}
	public void setEmployeeID(String employeeID) {
		this.employeeID = employeeID;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmployeeSalary() {
		return employeeSalary;
	}
	public void setEmployeeSalary(String employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
	
}
