package assignment22;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class PlayerMain {
    public static void displayPlayerName(String country,List<Player> playerlist){
    	List<String> playerName=new ArrayList<String>();
    	for(Player player:playerlist){
    		if(country.equals(player.getCountry().getCountryName())){
    			playerName.add(player.getPlayerName());
    		}
    	}
    	System.out.println("Player Name\n"+playerName);
    }
	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("resources/assignment22/palyerbeans.xml");
        Player player1=context.getBean("player1",Player.class);
        Player player2=context.getBean("player2",Player.class);
        Player player3=context.getBean("player3",Player.class);
        Player player4=context.getBean("player4",Player.class);
        Player player5=context.getBean("player5",Player.class);
        List<Player> playerList=new ArrayList<Player>();
        playerList.add(player1);
        playerList.add(player2);
        playerList.add(player3);
        playerList.add(player4);
        playerList.add(player5);
        System.out.println("Details of all Players");
        System.out.println(playerList);
        displayPlayerName("ST",playerList);
	}

}
