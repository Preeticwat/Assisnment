package Assignment1;

public class Client {

	public static void main(String[] args) {
		// creating an object for crud operations
		Employee_ employee = new Employee_();
		employee.setEmployeeName("First Employee");
		employee.setEmployeeId("A1234");
		employee.setEmployeeBand("Band4");
		Employee_DAO employee_DAO= new Employee_DAO();
		employee_DAO.createEmployee(employee);
		employee_DAO.retrieveEmployee("A1234");
		employee_DAO.updateEmployeeName("A1234","newName");
		employee_DAO.deleteEmployee("A1234");
	}

}
