package assignment4;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
	Connection conn= null;
	
	String connect(String drivername,String url,String username,String pwd) throws Exception{
		String result="failure";
		Class.forName(drivername);
		conn=DriverManager.getConnection(url,username,pwd);
		if(conn!=null){
			result="success";
		}
		return result;
	}

}
