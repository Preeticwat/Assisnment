package assignment5;
import javax.persistence.*;

@Entity  
@PrimaryKeyJoinColumn(name="employeeID")  
public class RegularEmployee extends Employee {
	   private String qplc;

		public String getQplc() {
			return qplc;
		}

		public void setQplc(String qplc) {
			this.qplc = qplc;
		}
        
}
