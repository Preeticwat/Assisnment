package assignment2;

import static org.junit.Assert.*;
import org.junit.*;
import assignment1.WordCount;

public class TestAsseration {
	@BeforeClass
	public static void setUpBeforeClass() throws Exception{
		System.out.println("before class");
	}
	
	@Before
	public void setUp() throws Exception{
		System.out.println("before");
	}
	@Test
	public void testSortArrayList() throws Exception{
		ArraySort arraySort=new ArraySort();
		int[] array={50,90,45,70,40,20};
		int[] expectedOutput={20,40,45,50,70,90};
		int[] methodOutput=arraySort.sortNumbers(array);
		assertArrayEquals(expectedOutput,methodOutput);
		
	}
	@AfterClass
	public static void tearDownAfterClass() throws Exception{
		System.out.println("after class");
	}
	
	@After
	public void tearDown() throws Exception{
		System.out.println("after");
	}
	
}
