package assignment42;

import java.util.List;
import org.springframework.context.*;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import assignment3.Student;

public class StudentMain {

	public static void main(String[] args) {
		ConfigurableApplicationContext context= new ClassPathXmlApplicationContext
				("resources/assignment42/studentbeans.xml");
		StudentDAO dao=context.getBean(StudentDAO.class);
		List<Student> studentList=dao.getAllDetails();
		System.out.println("Display All Student Details");
		for(Student list:studentList){
			System.out.println(list+"\n");
		}
        Student studentdetl=dao.getDetails("6");
        System.out.println("Display Student Details");
        System.out.println(studentdetl);
	}
}