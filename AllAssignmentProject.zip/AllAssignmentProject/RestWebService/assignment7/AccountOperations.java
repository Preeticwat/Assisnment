package assignments;

import org.springframework.web.bind.annotation.*;

@RestController
public class AccountOperations {
     Account account=new Account();
	@PostMapping("/deposit")
	public String deposit(@RequestParam("amount") double depositAmount){
	Double amount=account.getAmount();
	Double updatedAmount=amount+depositAmount;
	account.setAmount(updatedAmount);
	return "Deposit Sucessfully "+account.getAmount();
	}
	@PostMapping("/withdraw")
	public String withdraw(@RequestParam("amount") double withdrawAmount){
		Double amount=account.getAmount();
		Double updatedAmount=amount-withdrawAmount;
		account.setAmount(updatedAmount);
		return "Withdraw Sucessfully "+account.getAmount();
	}
	@GetMapping("/getBalance")
	public Double getBalance(){
		return account.getAmount();
		
	}
}
