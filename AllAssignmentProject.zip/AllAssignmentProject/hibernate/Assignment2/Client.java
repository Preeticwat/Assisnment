package Assignment2;

import java.util.HashSet;
import java.util.Set;

public class Client {

	public static void main(String[] args) {
		Department dept = new Department();
		dept.setDeptHead("QWERTY");
		dept.setDeptName("ABCD");

		Emplye emp1 = new Emplye();
		emp1.setEmployeeId("E1123");
		emp1.setEmpName("ABC");
		emp1.setDept(dept);

		Emplye emp2 = new Emplye();
		emp2.setEmployeeId("E12345");
		emp2.setEmpName("xyz");
		emp1.setDept(dept);

		Set<Emplye> employes = new HashSet<Emplye>();
		employes.add(emp1);
		employes.add(emp2);

		dept.setEmployees(employes);

		Employee_DAO empDao = new Employee_DAO();
		empDao.saveDept(dept);
		empDao.deleteDept("ABCD");
	}
}
