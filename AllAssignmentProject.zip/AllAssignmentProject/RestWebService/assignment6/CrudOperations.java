package assignments;

import org.springframework.web.bind.annotation.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

@RestController
public class CrudOperations {
	
	@PostMapping("/createEmp")
	public String createEmployee(@RequestBody Employee emp) {
		SessionFactory sessionFactory=null;
		Session session=null;
		
		try{
			sessionFactory=	new Configuration().configure().buildSessionFactory();
			session=sessionFactory.openSession();
			session.beginTransaction();
			session.save(emp);
			session.getTransaction().commit();
		} catch(Exception ex) {
			ex.printStackTrace();
         }finally {
             try {if(session != null) session.close();} catch(Exception ex) {}
         }
		return "Data Inserted";
}
	@PostMapping("/retrieveEmp")
	public Employee retrieveEmployee(@RequestParam("employeeId") String employeeId) {
		SessionFactory sessionFactory=null;
		Session session=null;
		 Employee emp=null;
		try{
			sessionFactory=	new Configuration().configure().buildSessionFactory();
			session=sessionFactory.openSession();
		    emp = session.get(Employee.class, employeeId);
		} catch(Exception ex) {
			ex.printStackTrace();
         }finally {
             try {if(session != null) session.close();} catch(Exception ex) {}
         }
		return emp;
		
	}
	
	@PostMapping("/updateEmp")
	public String updateEmployee(@RequestParam("employeeId") String employeeId,@RequestParam("updatedName") String updatedName) {
		SessionFactory sessionFactory=null;
		Session session=null;
	try{
		sessionFactory=	new Configuration().configure().buildSessionFactory();
		session=sessionFactory.openSession();
		session.beginTransaction();
		Employee emp = session.get(Employee.class, employeeId);
		String previousName=emp.getEmployeeName();
		emp.setEmployeeName(updatedName);
		session.save(emp);
		session.getTransaction().commit();}
	catch(Exception ex) {
			ex.printStackTrace();
     }finally {
             try {if(session != null) session.close();} catch(Exception ex) {}
         }
		
		return "updated Successfully";
	}
	
	@PostMapping("/deleteEmp")
	public String deleteEmployee(@RequestParam("employeeId") String employeeId) {
		SessionFactory sessionFactory=null;
		Session session=null;
	try{
		sessionFactory=	new Configuration().configure().buildSessionFactory();
		session=sessionFactory.openSession();
		session.beginTransaction();
		Employee emp = session.get(Employee.class, employeeId);
		session.delete(emp);
		session.getTransaction().commit();
	}
	catch(Exception ex) {
			ex.printStackTrace();
     }finally {
             try {if(session != null) session.close();} catch(Exception ex) {}
         }
	return "delete sucessfully";
	}
}
