package assignments;

import org.springframework.web.bind.annotation.*;

@RestController
public class DoubleIntegerValue {

	@PostMapping("doubleValue")
	public double doubleIntValue(@RequestParam("value") int value){
		Integer val=new Integer(value);
		double  dnum= val.doubleValue();
		return dnum;
		
	}
}
