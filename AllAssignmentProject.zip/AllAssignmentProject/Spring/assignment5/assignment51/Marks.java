package assignment51;

public class Marks {
	
private double science_Marks;
private double maths_Marks;
private double english_Marks;
public double getScience_Marks() {
	return science_Marks;
}
public void setScience_Marks(double science_Marks) {
	this.science_Marks = science_Marks;
}
public double getMaths_Marks() {
	return maths_Marks;
}
public void setMaths_Marks(double maths_Marks) {
	this.maths_Marks = maths_Marks;
}
public double getEnglish_Marks() {
	return english_Marks;
}
public void setEnglish_Marks(double english_Marks) {
	this.english_Marks = english_Marks;
}

}
