package assignments;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.*;

@RestController
public class MovieController {
	
	@GetMapping(value="/returnTextFormat" ,produces = "text/xml")
   public List<Movie> returnTextFormat(){
		List<Movie> movieList=movieList();
	    return movieList;
	   
   }
	
	@GetMapping(value="/returnXmlFormat" ,produces = "application/xml")
	   public List<Movie> returnXmlFormat(){
			List<Movie> movieList=movieList();
		    return movieList;
		   
	   }
	@GetMapping(value="/returnJSONFormat" ,produces = "application/json")
	   public List<Movie> returnJSONFormat(){
			List<Movie> movieList=movieList();
		    return movieList;
		   
	   }
	@GetMapping(value="/returnFormat" ,produces = "application/xml")
	   public Movie applicationFormat(@RequestParam("movieId") String movieId){
		Movie moviedetl=null;
		List<Movie> movieList=movieList();
		for(Movie movie:movieList){
			if(movieId.equals(movie.getMovieId())){
				moviedetl=movie;
			}}
		    return moviedetl;
		}
				
	public List<Movie> movieList(){
		List<Movie> list= new ArrayList<Movie>();
		Movie movie1= new Movie("M001","Top Gun","Tom Cruise",(float) 350000000.00);
		Movie movie2= new Movie("M002","abc","Tom",(float) 350000000.00);
		Movie movie3= new Movie("M003","wer","Cruise",(float) 350002300.00);
		Movie movie4= new Movie("M004","qwe","qwerty",(float) 351000000.00);
		Movie movie5= new Movie("M005","yui","asdfg",(float) 353000000.00);
		Movie movie6= new Movie("M006","aser","zxcvb",(float) 34000000.00);
		Movie movie7= new Movie("M007","hyui","yuiop",(float) 349000000.00);
		Movie movie8= new Movie("M008","mjio","hjkl",(float) 323000000.00);
		Movie movie9= new Movie("M009","mino","bnmkl",(float) 390000000.00);
		Movie movie10= new Movie("M0010","Topn","hjklop",(float) 300000000.00);
		list.add(movie1);
		list.add(movie2);
		list.add(movie3);
		list.add(movie4);
		list.add(movie5);
		list.add(movie6);
		list.add(movie7);
		list.add(movie8);
		list.add(movie9);
		list.add(movie10);
		
		return list;
	}
	
	
	

}
