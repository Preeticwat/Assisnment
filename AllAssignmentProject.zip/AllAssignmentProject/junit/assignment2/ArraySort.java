package assignment2;

import java.util.Arrays;

public class ArraySort {
int[] sortNumbers(int[] arr){
	Arrays.sort(arr);
	return arr;
}
}
