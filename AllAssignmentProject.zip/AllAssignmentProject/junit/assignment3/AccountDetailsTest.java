package assignment3;

import static org.junit.Assert.*;
import org.junit.*;

public class AccountDetailsTest {

	AccountDetails accountdetl=new AccountDetails();
	
	@Test
	public void acctNo(){
		int expected=1234567890;
		int acctno=accountdetl.acctNo(1234567890);
		assertEquals(expected,acctno);
	}
	
	@Test
	public void acctBalance(){
		double expected=1000;
		double delta=2;
		assertEquals(expected,accountdetl.acctBalance(1000),delta);
		
	}
	
	@Test
	public void creditCard(){
		assertTrue(accountdetl.creditCard()!=0);
		
	}
	
	
}
