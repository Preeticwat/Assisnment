package assignment21;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class StudentMain {

	public static void main(String[] args) {
		ApplicationContext context= new ClassPathXmlApplicationContext("resources/assignment2/studentbeans.xml");
		Student student1=context.getBean(Student.class);
		Test test1= new Test("101","java",90);
		Test test2=new Test("102","C++",100);
		List<Test> testList1=new ArrayList<Test>();
		testList1.add(test1);
		student1.setStudentId("001");
		student1.setStudentName("ABC");
		student1.setStudentTest(testList1);
		Student student2=context.getBean(Student.class);
		List<Test> testList2=new ArrayList<Test>();
		testList2.add(test1);
		testList2.add(test2);
		student2.setStudentId("001");
		student2.setStudentName("ABC");
		student2.setStudentTest(testList1);
		System.out.println(student1);
		System.out.println(student2);
		
	}

}
