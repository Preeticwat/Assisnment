package assignment3;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class StudentDAO {

	private Random randomData=new Random();
	private int value= 1;
	private List<Student> studentList=null;
	public Student createAndFill(Student classToBeInstantiated)throws Exception{
		Student instance=classToBeInstantiated.getClass().newInstance();
		for(Field field:classToBeInstantiated.getClass().getDeclaredFields()){
			field.setAccessible(true);
			Object value=getRandomValueForField(field);
			field.set(instance,value);
		}
		return instance;
	}
	private Object getRandomValueForField(Field field){
		String fieldName=field.getName();
		if(fieldName.equals("studentId")){
			return ""+value++;
		}else if(fieldName.equals("studentName")){
			return "Employee"+randomData.nextInt(100);
		}else if(fieldName.equals("studentAddress")){
			return "Address"+randomData.nextInt(100);
		}
		return null;
	}
	public List<Student> getAllDetails(){
		Student student=new Student();
		studentList=new ArrayList<Student>();
		try{
			for(int i=0;i<100;i++){
				Student studentInstance=createAndFill(student);
				studentList.add(studentInstance);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return studentList;
	}
	public Student getDetails(String studentId){
		Student studentdetl=null;
		for(Student student:studentList){
			if(studentId.equals(student.getStudentId())){
				studentdetl=student;
			}
		}
		return studentdetl;
	}
}
