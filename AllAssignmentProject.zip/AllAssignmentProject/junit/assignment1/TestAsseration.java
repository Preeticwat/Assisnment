package assignment1;
import static org.junit.Assert.*;
import org.junit.*;

public class TestAsseration {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception{
		System.out.println("before class");
	}
	
	@Before
	public void setUp() throws Exception{
		System.out.println("before");
	}
	@Test
	public void testValidWordCount() throws Exception{
		WordCount wordCount=new WordCount();
		int result=wordCount.count("Hello Are you there");
		assertTrue(result>0);
		assertFalse(result<=0);
	}
	@AfterClass
	public static void tearDownAfterClass() throws Exception{
		System.out.println("after class");
	}
	
	@After
	public void tearDown() throws Exception{
		System.out.println("after");
	}
	
}
