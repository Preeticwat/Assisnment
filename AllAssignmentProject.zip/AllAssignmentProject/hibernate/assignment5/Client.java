package assignment5;

public class Client {

	public static void main(String[] args) {
		ContractEmployee contractEmployee= new ContractEmployee();
		contractEmployee.setAllowance("1000");
		contractEmployee.setEmployeeID("101");
		contractEmployee.setEmployeeName("abcd");
		contractEmployee.setEmployeeSalary("100000");
		
		RegularEmployee regularEmployee=new RegularEmployee();
		regularEmployee.setQplc("abcd");
		regularEmployee.setEmployeeID("102");
		regularEmployee.setEmployeeName("abcde");
		regularEmployee.setEmployeeSalary("120000");
		EmployeeDAO employeeDAO= new EmployeeDAO();
		employeeDAO.saveContractEmployee(contractEmployee);
		employeeDAO.saveRegularEmployee(regularEmployee);
		employeeDAO.deleteEmployee("101");
		}

}
