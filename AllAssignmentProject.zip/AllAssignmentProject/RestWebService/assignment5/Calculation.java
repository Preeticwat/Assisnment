package assignments;

import org.springframework.web.bind.annotation.*;

@RestController
public class Calculation {

	@PostMapping("/add")
	public int add(@RequestParam("value1") int value1 ,@RequestParam("value2") int value2){
		int sum=Integer.sum(value1, value2);
		return sum;
		
	}
	@PostMapping("/subtract")
	public int subtract(@RequestParam("value1") int value1 ,@RequestParam("value2") int value2){
		int subtract=value1-value2;
		return subtract;
	}
}
