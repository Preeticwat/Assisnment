package assignment41;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;

import assignment3.Student;

public class StudentDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public List<Student> getAllDetails(){
		String sql="select * from student";
		
		return (List<Student>)jdbcTemplate.queryForObject(sql,assignment3.Student.class);
	}
	public Student getDetails(String studentId){
		String sql="select * from student where id'"+studentId+"'";
		 return jdbcTemplate.queryForObject(sql,assignment3.Student.class);
}
}