package Assignment2;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Employee_DAO {
	
	public void saveDept(Department dept) {
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		session.save(dept);
		session.getTransaction().commit();
		session.close();
		System.out.println("Succesfully saved "+ dept.getDeptName());
		
	}
	
	
	
	public void deleteDept(String deptName) {
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		Department dept=session.get(Department.class, deptName);
		session.delete(dept);
		session.getTransaction().commit();
		session.close();
		System.out.println("Succesfully deleted");
		
	}

}
