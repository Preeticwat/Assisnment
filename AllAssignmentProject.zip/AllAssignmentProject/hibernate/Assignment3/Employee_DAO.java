package Assignment3;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Employee_DAO {
	
	public void saveEmployee(Employe_ emp) {
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		session.save(emp);
		session.getTransaction().commit();
		session.close();
		System.out.println("Succesfully saved "+ emp.getEmployeeName());
		
	}
	
	public void deleteEmployee(String employeeId) {
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		Employe_ emp = session.get(Employe_.class, employeeId);
		session.delete(emp);
		session.getTransaction().commit();
		session.close();
		System.out.println("Succesfully deleted");
		
	}

}
