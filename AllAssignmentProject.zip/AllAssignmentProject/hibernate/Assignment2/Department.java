package Assignment2;



import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Department {

	@Id
	private String deptName;

	private String deptHead;

	@OneToMany(mappedBy="dept",cascade=CascadeType.ALL)
	private Set<Emplye> employees;

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getDeptHead() {
		return deptHead;
	}

	public void setDeptHead(String deptHead) {
		this.deptHead = deptHead;
	}

	public Set<Emplye> getEmployees() {
		return employees;
	}

	public void setEmployees(Set<Emplye> employees) {
		this.employees = employees;
	}

	

	

}
