package assignment12;

import org.springframework.context.annotation.Bean;

import assignment11.Movie;

public class MovieConfig {

	@Bean
	public Movie movie(){
	return new Movie();
	
	}
}
