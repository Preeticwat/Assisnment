package assignment5;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.*;

@RunWith(Parameterized.class)
public class TestBook {
private int price;
private double discount;
private double delta=2;
private double expectedResult;
private Book book;
private TestBook(int price,double discount,double expectedResult){
	super();
	this.price=price;
	this.discount=discount;
	this.expectedResult=expectedResult;
}

@Before
public void initalize(){
	book= new Book();
}
@Parameterized.Parameters
public static Collection input(){
	return Arrays.asList(new Object[][]{{1000,200,800},{2000,800,1200},{700,200,500},{900,200,700}});
	}
public void testBookPrice(){
	assertEquals(expectedResult,book.discountedPrice(price, discount),delta);
}
}
