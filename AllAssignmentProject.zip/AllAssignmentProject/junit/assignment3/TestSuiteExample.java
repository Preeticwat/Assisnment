package assignment3;

import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
import org.junit.runners.RunWith;

@RunWith(Suite.class)
@SuiteClasses(AccountDetailsTest.class)
public class TestSuiteExample {

}
