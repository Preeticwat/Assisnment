package Assignment4;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Students {
	@Id
	private String studentId;
	private String studentName;

	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(
	        name = "Student_Course", 
	        joinColumns = {@JoinColumn(name="Student_ID") },
	        inverseJoinColumns= {@JoinColumn(name="Course_ID")}
	    )
	private Set<Course> courses=new HashSet<>();

	public String getStudentId() {
		return studentId;
	}

	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public Set<Course> getCourses() {
		return courses;
	}

	public void setCourses(Set<Course> courses) {
		this.courses = courses;
	}

}
