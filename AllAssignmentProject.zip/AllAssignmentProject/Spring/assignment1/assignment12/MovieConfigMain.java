package assignment12;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import assignment11.Movie;


public class MovieConfigMain {

	public static void main(String[] args) {
		ApplicationContext context= new 
	                     AnnotationConfigApplicationContext(MovieConfig.class);
		Movie movie=context.getBean(Movie.class);
		movie.setMovieId("M001");
		movie.setMovieName("The Firm");
		movie.setMovieActor("Tom Cruise");
		System.out.println(movie);
		
	}

}
